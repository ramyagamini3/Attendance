
<?php include "header1.php" ?>
<head>
  <style>
    td
	{
      font-family: "Times New Roman", Times, serif;
    }
 </style>

</head>

<table style="widtd:100%">
	  <tr>
		<td align="left"><b>ADDRESS</b></td>
		<td align="center"><b>CONTACT</b></td> 

	  </tr>
	  <tr>
		<td align="left">Chinna Amiram, Bhimavaram-534204, AP, India.</td>
		<td align="center">08816-223332</td> 
	  </tr>
</table>
<table style="widtd:100%">
	  <tr>
		<td align="left"><b>PRINCIPAL NAME</b></td>
		<td align="center"><b>CONTACT</b></td> 

	  </tr>
	  <tr>
		<td align="left">G P S VARMA</td>
		<td align="center">8888888888</td> 
	  </tr>
</table>
<table  style="widtd:100%">
	  <tr>
		<td align="left"><b>DEPARTMENT NAME</b></td>
		<td align="center"><b>H.O.D NAME</b></td> 
		<td align="right"><b>CONTACT</b></td> 

	  </tr>
	  <tr>
		<td align="left">INFORMATION TECHNOLOGY</td>
		<td align="center">Adharsh</td> 
		<td align="right">1234567890</td> 
	  </tr>
	  
	  <tr>
		<td align="left">COMPUTER SCIENCE</td>
		<td align="center">RAMYA</td> 
		<td align="right">1234567890</td> 
	  </tr>
			
	  <tr>
		<td align="left">MECHANICAL</td>
		<td align="center">RAVI TEJA</td> 
		<td align="right">1234567890</td> 
	  </tr>
	  <tr>
		<td align="left">ELECTRICAL</td>
		<td align="center">ANUDEEP</td> 
		<td align="right">1234567890</td> 
	  </tr>
	  <tr>
		<td align="left">ELECTRONICS</td>
		<td align="center">KAVYA</td> 
		<td align="right">1234567890</td> 
	  </tr>
	  <tr>
		<td align="left">CIVIL</td>
		<td align="center">swapna</td> 
		<td align="right">1234567890</td> 
	  </tr>
</table>
<?php include "footer.php";?>

	